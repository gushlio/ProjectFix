﻿namespace GameReviewLibrary
{
    public class Class1
    {

    }
}
